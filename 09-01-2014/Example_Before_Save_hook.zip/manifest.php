<?php

    $manifest =array(
        'acceptable_sugar_flavors' => array('CE','PRO','CORP','ENT','ULT'),
        'acceptable_sugar_versions' => array(
            'regex_matches' => array(
					'7.5.0.0'
				),
        ),
        'author' => 'SugarCRM',
        'description' => 'Installs a sample before_save logic hook',
        'icon' => '',
        'is_uninstallable' => true,
        'name' => 'Example Before Save Logic Hook Installer',
        'published_date' => '2015-01-09 2015 15:51:49',
        'type' => 'module',
        'version' => '1341607504',
    );
    
    $installdefs =array(
        'id' => 'package_1341607504',
        'copy' => array(
            0 => array(
                'from' => '<basepath>/Files/custom/modules/Accounts/logic_hooks.php',
                'to' => 'custom/modules/Accounts/logic_hooks.php',
            ),
			1 => array(
                'from' => '<basepath>/Files/custom/modules/Accounts/logic_hooks_class.php',
                'to' => 'custom/modules/Accounts/logic_hooks_class.php',
            ),
        ),
        /*'logic_hooks' => array(
            array(
                'module' => 'Accounts',
                'hook' => 'before_save',
                'order' => 99,
                'description' => 'Example Logic Hook - Updates account name',
                'file' => 'custom/modules/Accounts/logic_hooks.php',
                'class' => 'logic_hooks_accounts_class',
                'function' => 'updateAccountName',
            ),
        ),*/
    );

?>