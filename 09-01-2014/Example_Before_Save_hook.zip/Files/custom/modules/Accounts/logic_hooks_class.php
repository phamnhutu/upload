<?php
	 if (!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
   
    class logic_hooks_accounts_class
    {
        function before_save_method($bean, $event, $arguments)
        {
            $bean->name = 'CMC '.$bean->name;
        }
    }
?>